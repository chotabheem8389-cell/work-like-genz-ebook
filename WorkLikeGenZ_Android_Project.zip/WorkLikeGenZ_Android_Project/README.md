# Work Like Gen-Z — Offline Android App Project

This Android Studio project wraps the supplied bilingual 3D eBook in an Android WebView.
The book HTML and its cover art are bundled in `app/src/main/assets/index.html`, so the core
reading experience works offline. (Externally loaded fonts may fall back to system fonts.)

## Build an APK
1. Open Android Studio on a computer.
2. Choose **Open** and select this `WorkLikeGenZ_Android_Project` folder.
3. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the output location, usually `app/build/outputs/apk/debug/app-debug.apk`.

This is the Android Studio source project, not a precompiled APK. Building the APK requires Android Studio/Android SDK.
